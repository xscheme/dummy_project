#!/usr/local/bin/python

import sys
import math
import imageio

# usage: file_decoder.py img file_count original_file_size [row_offset col_offset]

BG_COLOR = [14, 14, 14]

FIXED_WIDTH = 1880
MAX_ROW = 900

DATA_PER_PIXEL = 3
PIXELS_PER_BYTE = 4

ONE_ROW_SIZE = FIXED_WIDTH * DATA_PER_PIXEL

ACTUAL_ONE_ROW_SIZE = ONE_ROW_SIZE / PIXELS_PER_BYTE
ACTUAL_MAX_ROW = MAX_ROW

ACTUAL_ONE_IMG_SIZE = ACTUAL_ONE_ROW_SIZE * ACTUAL_MAX_ROW

def usage():
	print("usage: file_decoder bitmap_file file_count file_size")

arg_count = len(sys.argv)
if arg_count < 3:
	usage()
	sys.exit(1)

file_name = sys.argv[1]
file_count = int(sys.argv[2])
residual_bytes = int(sys.argv[3])

row_offset = None
col_offset = None
if len(sys.argv) > 4:
	row_offset = int(sys.argv[4])
	col_offset = int(sys.argv[5])

file_count = file_count - 1

merged_file = open("merged_file.bin", "wb")

for i in range(file_count + 1):

	check_sum = 0

	current_file = file_name + "_" + str(i) + ".bmp"
	current_file_size = ACTUAL_ONE_IMG_SIZE

	if i == file_count:
		# last file
		current_file_size = residual_bytes
		current_file = file_name + ".bmp"
	else:
		residual_bytes = residual_bytes - ACTUAL_ONE_IMG_SIZE

	print("current file: ", current_file)

	binary_file = imageio.imread(current_file)
	current_img_height = len(binary_file)
	current_img_width = len(binary_file[0])

	# check row/column offset
	if not row_offset:

		# col offset
		flag = False
		for j in range(current_img_width):

			if flag:
				break

			for i in range(current_img_height):
				if binary_file[i, j, 0] != BG_COLOR[0] or binary_file[i, j, 1] != BG_COLOR[1] or binary_file[i, j, 2] != BG_COLOR[2]:
					print("Row: pixel spotted [{0}, {1}]".format(j, i))
					row_offset = j
					flag = True
					break

		# row offset
		flag = False
		for i in range(current_img_height):
		
			if flag:
				break

			for j in range(current_img_width):
				if binary_file[i, j, 0] != BG_COLOR[0] or binary_file[i, j, 1] != BG_COLOR[1] or binary_file[i, j, 2] != BG_COLOR[2]:
					print("Col: pixel spotted [{0}, {1}]".format(j, i))
					col_offset = i
					flag = True
					break

	print("Row offset: ", row_offset)
	print("Col offset: ", col_offset)

	# read img file 
	current_file_bytes = [0] * current_file_size
	for i in range(current_file_size):

		row_i = math.floor(i / ACTUAL_ONE_ROW_SIZE)
		col_i = math.floor((i % ACTUAL_ONE_ROW_SIZE) / DATA_PER_PIXEL)
		rgb_i = i % DATA_PER_PIXEL
		
		merged_byte = 0
		
		for j in range(0, PIXELS_PER_BYTE):
		
			decoded_byte = 0
			shift_bits = 2 * (PIXELS_PER_BYTE - 1 - j)
			
			decoded_byte = binary_file[row_i + row_offset, PIXELS_PER_BYTE * col_i + j + col_offset, rgb_i]
			decoded_byte = decoded_byte & 0b11000000
			decoded_byte = decoded_byte >> shift_bits

			merged_byte = merged_byte + decoded_byte

		current_file_bytes[i] = merged_byte
		check_sum += merged_byte

	arr = bytearray(current_file_bytes)
	merged_file.write(arr)

	print("check sum: ", check_sum)

merged_file.close()
